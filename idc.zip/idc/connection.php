<?php

    $servername="sql306.ezyro.com";
    $username="ezyro_30763108";
    $password="Trantiendat2274@";
    $dbname="ezyro_30763108_trantiendat_idc";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if(!$conn){
        die("Connection failed: ".mysqli_connect_error());
    }

 ?>