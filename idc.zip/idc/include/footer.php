      <footer class="py-4 bg-dark text-white-50 fixed-bottom">
        <div class="container text-center">
          <small>Phát triển bởi <a class="text-white" href="http://trantiendat.ezyro.com" target="_blank"> Trần Tiến Đạt và Tran Tien Dat Network (TTDN.,JSC)</a> | Bảo lưu tất cả các quyền. © 2018</small>
        </div>
      </footer>

      <!-- Bootstrap core JavaScript-->
      <script src="vendor/jquery-3.4.1.min.js"></script>
      <script src="vendor/bootstrap/popper.min.js"></script>
      <script src="vendor/bootstrap/bootstrap.min.js"></script>
  </body>

</html>